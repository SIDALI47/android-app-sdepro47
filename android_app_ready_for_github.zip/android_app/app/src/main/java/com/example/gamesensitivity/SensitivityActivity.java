package com.example.gamesensitivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SensitivityActivity extends Activity {

    private String gameName;
    private String deviceInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensitivity);

        // Get game name from intent
        Intent intent = getIntent();
        gameName = intent.getStringExtra("game");

        // Get device information
        deviceInfo = Build.MANUFACTURER + " " + Build.MODEL;

        // Set up UI elements
        TextView gameNameText = findViewById(R.id.tv_game_name);
        TextView deviceInfoText = findViewById(R.id.tv_device_info);
        Button applyButton = findViewById(R.id.btn_apply_settings);
        Button saveButton = findViewById(R.id.btn_save_settings);

        gameNameText.setText(gameName);
        deviceInfoText.setText("Device: " + deviceInfo);

        // Load sensitivity settings based on game and device
        loadSensitivitySettings();

        applyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SensitivityActivity.this, DisplaySettingsActivity.class);
                intent.putExtra("game", gameName);
                intent.putExtra("device", deviceInfo);
                startActivity(intent);
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSensitivitySettings();
            }
        });
    }

    private void loadSensitivitySettings() {
        // Load sensitivity settings based on game and device
        SensitivityData data = SensitivityDatabase.getSensitivityData(gameName, deviceInfo);
        
        TextView cameraSensitivity = findViewById(R.id.tv_camera_sensitivity);
        TextView adsSensitivity = findViewById(R.id.tv_ads_sensitivity);
        TextView gyroSensitivity = findViewById(R.id.tv_gyro_sensitivity);

        if (data != null) {
            cameraSensitivity.setText("Camera: " + data.getCameraSensitivity());
            adsSensitivity.setText("ADS: " + data.getAdsSensitivity());
            gyroSensitivity.setText("Gyroscope: " + data.getGyroSensitivity());
        } else {
            // Default values if no specific data found
            cameraSensitivity.setText("Camera: Default settings");
            adsSensitivity.setText("ADS: Default settings");
            gyroSensitivity.setText("Gyroscope: Default settings");
        }
    }

    private void saveSensitivitySettings() {
        SensitivityData dataToSave = SensitivityDatabase.getSensitivityData(gameName, deviceInfo);

        if (dataToSave != null) {
            SavedSettingsManager.saveSettings(this, dataToSave);
            Toast.makeText(this, "Settings saved!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No settings to save for this game/device.", Toast.LENGTH_SHORT).show();
        }
    }
}

