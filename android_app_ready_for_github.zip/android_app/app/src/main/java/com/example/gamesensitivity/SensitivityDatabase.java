package com.example.gamesensitivity;

import java.util.HashMap;
import java.util.Map;

public class SensitivityDatabase {
    
    private static Map<String, SensitivityData> database = new HashMap<>();
    
    static {
        // Initialize database with sample data
        initializeDatabase();
    }
    
    private static void initializeDatabase() {
        // PUBG Mobile settings for different devices
        database.put("PUBG Mobile_Samsung", new SensitivityData(
            "PUBG Mobile", "Samsung", 
            "TPP No Scope: 95-100%, Red Dot: 90-95%, 2x: 120-125%",
            "No Scope: 95-100%, Red Dot: 55-60%, 2x: 37-42%",
            "No Scope: 300-350%, Red Dot: 280-300%, 2x: 250-270%"
        ));
        
        database.put("PUBG Mobile_Xiaomi", new SensitivityData(
            "PUBG Mobile", "Xiaomi", 
            "TPP No Scope: 90-95%, Red Dot: 85-90%, 2x: 115-120%",
            "No Scope: 90-95%, Red Dot: 50-55%, 2x: 32-37%",
            "No Scope: 280-330%, Red Dot: 260-280%, 2x: 230-250%"
        ));
        
        // Free Fire settings
        database.put("Free Fire_Samsung", new SensitivityData(
            "Free Fire", "Samsung",
            "General: 90-100, Red Dot: 90, 2X Scope: 85",
            "4X Scope: 70-80, Sniper Scope: 58-60",
            "Free Look: 67"
        ));
        
        database.put("Free Fire_Xiaomi", new SensitivityData(
            "Free Fire", "Xiaomi",
            "General: 85-95, Red Dot: 85, 2X Scope: 80",
            "4X Scope: 65-75, Sniper Scope: 53-58",
            "Free Look: 62"
        ));
        
        // Delta Force settings
        database.put("Delta Force_Samsung", new SensitivityData(
            "Delta Force", "Samsung",
            "Total Touch: 75, Rotation: 120, 2x-4x Scope: 100",
            "6x Scope: 139, 7x Scope: 143",
            "Gyro Sensitivity: 241, Vertical: 148, Horizontal: 138"
        ));
        
        database.put("Delta Force_Xiaomi", new SensitivityData(
            "Delta Force", "Xiaomi",
            "Total Touch: 70, Rotation: 115, 2x-4x Scope: 95",
            "6x Scope: 130, 7x Scope: 135",
            "Gyro Sensitivity: 230, Vertical: 140, Horizontal: 130"
        ));
    }
    
    public static SensitivityData getSensitivityData(String gameName, String deviceInfo) {
        // Extract manufacturer from device info
        String manufacturer = extractManufacturer(deviceInfo);
        String key = gameName + "_" + manufacturer;
        
        SensitivityData data = database.get(key);
        if (data == null) {
            // Return default data if specific combination not found
            return getDefaultData(gameName);
        }
        return data;
    }
    
    private static String extractManufacturer(String deviceInfo) {
        if (deviceInfo.toLowerCase().contains("samsung")) return "Samsung";
        if (deviceInfo.toLowerCase().contains("xiaomi")) return "Xiaomi";
        if (deviceInfo.toLowerCase().contains("huawei")) return "Huawei";
        if (deviceInfo.toLowerCase().contains("oppo")) return "Oppo";
        if (deviceInfo.toLowerCase().contains("vivo")) return "Vivo";
        if (deviceInfo.toLowerCase().contains("oneplus")) return "OnePlus";
        return "Generic";
    }
    
    private static SensitivityData getDefaultData(String gameName) {
        switch (gameName) {
            case "PUBG Mobile":
                return new SensitivityData(gameName, "Generic",
                    "TPP No Scope: 95%, Red Dot: 90%, 2x: 120%",
                    "No Scope: 95%, Red Dot: 55%, 2x: 37%",
                    "No Scope: 300%, Red Dot: 280%, 2x: 250%");
            case "Free Fire":
                return new SensitivityData(gameName, "Generic",
                    "General: 90, Red Dot: 90, 2X Scope: 85",
                    "4X Scope: 70, Sniper Scope: 58",
                    "Free Look: 67");
            case "Delta Force":
                return new SensitivityData(gameName, "Generic",
                    "Total Touch: 75, Rotation: 120, Scopes: 100",
                    "High Scopes: 139-143",
                    "Gyro: 241, Vertical: 148, Horizontal: 138");
            default:
                return null;
        }
    }
}

