package com.example.gamesensitivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DisplaySettingsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_settings);

        Intent intent = getIntent();
        String gameName = intent.getStringExtra("game");
        String deviceInfo = intent.getStringExtra("device");

        TextView gameNameText = findViewById(R.id.tv_display_game_name);
        TextView deviceInfoText = findViewById(R.id.tv_display_device_info);
        TextView settingsText = findViewById(R.id.tv_settings_details);
        TextView instructionsText = findViewById(R.id.tv_instructions);
        Button backButton = findViewById(R.id.btn_back);

        gameNameText.setText(gameName);
        deviceInfoText.setText("Device: " + deviceInfo);

        // Get sensitivity data
        SensitivityData data = SensitivityDatabase.getSensitivityData(gameName, deviceInfo);
        
        if (data != null) {
            String settingsDetails = "Camera Sensitivity:\n" + data.getCameraSensitivity() + 
                                   "\n\nADS Sensitivity:\n" + data.getAdsSensitivity() + 
                                   "\n\nGyroscope Sensitivity:\n" + data.getGyroSensitivity();
            settingsText.setText(settingsDetails);
        }

        // Set instructions based on game
        String instructions = getInstructionsForGame(gameName);
        instructionsText.setText(instructions);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private String getInstructionsForGame(String gameName) {
        switch (gameName) {
            case "PUBG Mobile":
                return "Instructions:\n" +
                       "1. Open PUBG Mobile\n" +
                       "2. Go to Settings > Sensitivity\n" +
                       "3. Adjust Camera, ADS, and Gyroscope settings\n" +
                       "4. Test in Training Mode";
            case "Free Fire":
                return "Instructions:\n" +
                       "1. Open Free Fire\n" +
                       "2. Go to Settings > Sensitivity\n" +
                       "3. Adjust General, Red Dot, and Scope settings\n" +
                       "4. Test in Practice Range";
            case "Delta Force":
                return "Instructions:\n" +
                       "1. Open Delta Force Mobile\n" +
                       "2. Go to Settings > Controls > Sensitivity\n" +
                       "3. Adjust Touch and Gyroscope settings\n" +
                       "4. Test in Training Ground";
            default:
                return "Please refer to your game's settings menu.";
        }
    }
}

