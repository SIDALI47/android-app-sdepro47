package com.example.gamesensitivity;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class SavedSettingsManager {

    private static final String PREF_NAME = "GameSensitivityPrefs";
    private static final String KEY_SAVED_SETTINGS = "saved_settings";

    public static void saveSettings(Context context, SensitivityData data) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        
        List<SensitivityData> savedList = getSavedSettings(context);
        // Check if this setting already exists and update it, otherwise add new
        boolean found = false;
        for (int i = 0; i < savedList.size(); i++) {
            SensitivityData existingData = savedList.get(i);
            if (existingData.getGameName().equals(data.getGameName()) && 
                existingData.getDeviceModel().equals(data.getDeviceModel())) {
                savedList.set(i, data);
                found = true;
                break;
            }
        }
        if (!found) {
            savedList.add(data);
        }

        String json = gson.toJson(savedList);
        editor.putString(KEY_SAVED_SETTINGS, json);
        editor.apply();
    }

    public static List<SensitivityData> getSavedSettings(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = prefs.getString(KEY_SAVED_SETTINGS, null);
        if (json == null) {
            return new ArrayList<>();
        }
        Type type = new TypeToken<ArrayList<SensitivityData>>() {}.getType();
        return gson.fromJson(json, type);
    }

    public static void clearSavedSettings(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(KEY_SAVED_SETTINGS);
        editor.apply();
    }
}

