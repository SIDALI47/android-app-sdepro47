package com.example.gamesensitivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.List;

public class SavedSettingsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_settings);

        TextView savedSettingsText = findViewById(R.id.tv_saved_settings);
        Button backButton = findViewById(R.id.btn_back_saved);

        // Load saved settings
        List<SensitivityData> savedSettings = SavedSettingsManager.getSavedSettings(this);
        
        if (savedSettings.isEmpty()) {
            savedSettingsText.setText("No saved settings yet.\n\nSave your preferred settings from the sensitivity screen to see them here.");
        } else {
            StringBuilder settingsText = new StringBuilder();
            for (int i = 0; i < savedSettings.size(); i++) {
                SensitivityData data = savedSettings.get(i);
                settingsText.append("Game: ").append(data.getGameName()).append("\n");
                settingsText.append("Device: ").append(data.getDeviceModel()).append("\n");
                settingsText.append("Camera: ").append(data.getCameraSensitivity()).append("\n");
                settingsText.append("ADS: ").append(data.getAdsSensitivity()).append("\n");
                settingsText.append("Gyroscope: ").append(data.getGyroSensitivity()).append("\n");
                
                if (i < savedSettings.size() - 1) {
                    settingsText.append("\n---\n\n");
                }
            }
            savedSettingsText.setText(settingsText.toString());
        }

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}

