package com.example.gamesensitivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button pubgButton = findViewById(R.id.btn_pubg);
        Button freeFireButton = findViewById(R.id.btn_free_fire);
        Button deltaForceButton = findViewById(R.id.btn_delta_force);
        Button savedSettingsButton = findViewById(R.id.btn_saved_settings);

        pubgButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SensitivityActivity.class);
                intent.putExtra("game", "PUBG Mobile");
                startActivity(intent);
            }
        });

        freeFireButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SensitivityActivity.class);
                intent.putExtra("game", "Free Fire");
                startActivity(intent);
            }
        });

        deltaForceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SensitivityActivity.class);
                intent.putExtra("game", "Delta Force");
                startActivity(intent);
            }
        });

        savedSettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SavedSettingsActivity.class);
                startActivity(intent);
            }
        });
    }
}

