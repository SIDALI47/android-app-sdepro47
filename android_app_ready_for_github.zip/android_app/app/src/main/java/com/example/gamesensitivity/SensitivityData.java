package com.example.gamesensitivity;

public class SensitivityData {
    private String gameName;
    private String deviceModel;
    private String cameraSensitivity;
    private String adsSensitivity;
    private String gyroSensitivity;

    public SensitivityData(String gameName, String deviceModel, 
                          String cameraSensitivity, String adsSensitivity, String gyroSensitivity) {
        this.gameName = gameName;
        this.deviceModel = deviceModel;
        this.cameraSensitivity = cameraSensitivity;
        this.adsSensitivity = adsSensitivity;
        this.gyroSensitivity = gyroSensitivity;
    }

    // Getters
    public String getGameName() { return gameName; }
    public String getDeviceModel() { return deviceModel; }
    public String getCameraSensitivity() { return cameraSensitivity; }
    public String getAdsSensitivity() { return adsSensitivity; }
    public String getGyroSensitivity() { return gyroSensitivity; }

    // Setters
    public void setGameName(String gameName) { this.gameName = gameName; }
    public void setDeviceModel(String deviceModel) { this.deviceModel = deviceModel; }
    public void setCameraSensitivity(String cameraSensitivity) { this.cameraSensitivity = cameraSensitivity; }
    public void setAdsSensitivity(String adsSensitivity) { this.adsSensitivity = adsSensitivity; }
    public void setGyroSensitivity(String gyroSensitivity) { this.gyroSensitivity = gyroSensitivity; }
}

